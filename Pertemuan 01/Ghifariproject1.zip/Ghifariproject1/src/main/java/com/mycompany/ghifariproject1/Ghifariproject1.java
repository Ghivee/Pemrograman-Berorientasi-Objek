/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ghifariproject1;

/**
 *
 * @author acer
 */
public class Ghifariproject1 {

    public static void main(String[] args) {
        System.out.println("Nama   : Galang Ahmad Ghifari");
        System.out.println("NPM    : 2440506068");
        System.out.println("Alamat : Jalan Raya Kenteng, Kec. Madukara, Kab. Banjarnegara");
        System.out.println("No. HP : 081234567890");
    }
}
